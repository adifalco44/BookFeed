To compile the program (on a Bash on Ubuntu on Windows VM) sime type
$(cat command). To run the program, fire up the executable and feed
the input as described in the handout. It will generate the described
output.

Hope u like it.
