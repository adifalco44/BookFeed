#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gmp.h>
#include <pbc.h>
#define DEBUG 1


int main(void){

   // Init from file pointer
   pairing_t pairing;
   char param[1024];
   FILE *fp;
   fp = fopen("../pbc-0.5.14/param/a.param","r+");
   size_t count = fread(param,1024,1,fp); 
   pairing_init_set_buf(pairing,param,sizeof(param));

   // Inputs
   element_t g1,m,sk,mPrime,sigmaPrime,pkPrime;
   int b,byteCount;
   char input1[BUFSIZ];

   // Read 1st Line
   fgets(input1,BUFSIZ,stdin);
   element_init_G1(g1,pairing);
   element_set_str(g1,(const char *)input1,10);

   // Read 2nd Line
   fgets(input1,BUFSIZ,stdin);
   char *tmp1 = strtok(input1,",");
   char *message = strdup(tmp1);
   char *tmp2 = strtok(NULL,",");
   element_init_G1(m,pairing);
   element_set_str(m,(const char *)tmp1,10);
   element_init_Zr(sk,pairing);
   element_set_str(sk,(const char *)tmp2,10); 

   // 3rd Line
   fgets(input1,BUFSIZ,stdin);

   char *mPr = strtok(input1,",");
   char *sigTmp1 = strtok(NULL,",");
   char *sigTmp2 = strtok(NULL,",");
   char sigStr[BUFSIZ];
   sprintf(sigStr,"%s,%s",sigTmp1,sigTmp2);
   
   char *pkTmp1 = strtok(NULL,",");
   char *pkTmp2 = strtok(NULL,",");
   char pkStr[BUFSIZ];
   sprintf(pkStr,"%s,%s",pkTmp1,pkTmp2);

   // More Inits
   element_init_G1(mPrime,pairing);
   element_set_str(mPrime,(const char *)mPr,10);
   element_init_G1(sigmaPrime,pairing);
   element_set_str(sigmaPrime,(const char *)sigStr,10);
   element_init_G1(pkPrime,pairing);
   element_set_str(pkPrime,(const char *)pkStr,10);

   // Intermediate Values
   element_t hash,h;
   element_init_Zr(hash,pairing);
   element_init_G1(h,pairing);
   element_from_hash(hash,(void *)message,strlen(message));
   element_pow_zn(h,g1,hash);
   puts(tmp1);

   element_t hash2,h2;
   element_init_Zr(hash2,pairing);
   element_init_G1(h2,pairing);
   element_from_hash(hash2,(void *)tmp1,strlen(tmp1));
   element_pow_zn(h2,g1,hash2);

   // Find sigma
   element_t sigma;
   element_init_G1(sigma,pairing);
   element_pow_zn(sigma,h,sk);

   // Pairing Stuff
   element_t t1,t2;
   element_init_GT(t1,pairing);
   element_init_GT(t2,pairing);
   element_pairing(t1,h2,pkPrime);
   element_pairing(t2,sigmaPrime,g1);
   element_printf("%B,%B\n",sigma,g1);
   if (!element_cmp(t1,t2)){
   	puts("1");
   }else{
   	puts("0");
   }
}
